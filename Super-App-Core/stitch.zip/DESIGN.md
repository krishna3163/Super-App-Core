# Design System Specification: The Editorial Super-App

## 1. Overview & Creative North Star: "The Digital Curator"
This design system moves away from the "utility-first" clutter of traditional super-apps. Our Creative North Star is **The Digital Curator**. We treat every screen—whether it’s a food delivery interface or a social feed—as a high-end editorial spread. 

By leveraging **intentional asymmetry**, **overlapping glass layers**, and **high-contrast typography scales**, we break the rigid "template" feel. The goal is to make the user feel they are navigating a premium physical magazine that adapts to their needs, rather than a dense database of services.

---

## 2. Colors: Tonal Depth & Module Logic
We utilize a sophisticated palette where color is used for *intent* rather than decoration. Our primary Indigo leads the brand's trust, while modular accents define the ecosystem's pillars.

### Core Brand Tokens
- **Primary (`#0058bb`)**: The "Trust Anchor." Used for high-level brand moments and core navigation.
- **Secondary (`#006a26`)**: "The Social Pulse." Dedicated to Communication and Chat modules.
- **Tertiary (`#8a2ab9`)**: "The Lifestyle Layer." Dedicated to Services, Marketplace, and Dating.

### The "No-Line" Rule
**Explicit Instruction:** Designers are prohibited from using 1px solid borders to section content. Boundaries must be defined solely through background color shifts or tonal transitions.
- *Example:* Place a `surface-container-low` component on a `surface` background to create a "ghost" boundary.

### The "Glass & Gradient" Rule
To elevate the UI beyond standard flat design:
- **Floating Overlays:** Use `surface_variant` with a 60% opacity and a `20px` backdrop-blur for all modals and navigation bars.
- **Signature Textures:** Apply a linear gradient from `primary` to `primary_container` on main CTAs to add "soul" and depth.

---

## 3. Typography: Editorial Authority
We pair **Manrope** (Display/Headlines) with **Inter** (Body/Labels) to create a hierarchy that feels both authoritative and approachable.

- **Display-LG (56px, Manrope):** Reserved for hero marketplace categories or social story headlines. Use `-0.04em` tracking for a tight, high-end look.
- **Headline-MD (28px, Manrope):** For section titles (e.g., "Nearby Services").
- **Title-SM (16px, Inter, Medium):** For actionable sub-headers and card titles.
- **Body-MD (14px, Inter, Regular):** The workhorse for chat messages and product descriptions.
- **Label-SM (11px, Inter, Bold/Uppercase):** For metadata, tags, and micro-copy.

---

## 4. Elevation & Depth: Tonal Layering
Traditional drop shadows are often a crutch for poor layout. This system uses **Tonal Layering** to convey hierarchy.

### The Layering Principle
Depth is achieved by "stacking" the surface-container tiers. 
- **Base:** `surface` (#f7f5ff)
- **Sectioning:** `surface-container-low` (#efefff)
- **Active Cards:** `surface-container-lowest` (#ffffff)
- **Nesting Logic:** An inner "Quick Reply" box in a chat window should use `surface-container-high` to feel "recessed" or "elevated" relative to its parent.

### Ambient Shadows & Ghost Borders
- **Shadows:** Only for floating Action Buttons or High-Level Modals. Use the `on-surface` color at 6% opacity with a `32px` blur and `12px` Y-offset.
- **Ghost Borders:** If accessibility requires a stroke, use `outline-variant` at 15% opacity. Never use 100% opaque borders.

---

## 5. Components: The Primitive Set

### Buttons: High-Engagement Triggers
- **Primary:** Gradient fill (`primary` to `primary_container`), `DEFAULT` (16px) corner radius. Use `on_primary_fixed` for text to ensure high contrast.
- **Secondary:** Transparent background with a `surface_variant` glass effect and 10% `outline`.
- **States:** On hover, increase the background opacity by 10%. On press, scale the component to 0.98.

### Input Fields: Clean & Minimal
- **Styling:** No bottom line or full border. Use `surface-container-highest` background with a `DEFAULT` (16px) radius.
- **Focus:** Transition background to `surface-container-low` and add a `2px` "Ghost Border" of the `primary` color at 20% opacity.

### Cards & Lists: The "No-Divider" Mandate
- **Grid Layouts:** Forbid the use of divider lines. 
- **Separation:** Use `spacing-8` (2rem) of vertical white space or a subtle shift from `surface` to `surface-container-low` to separate service categories (e.g., Food vs. Rides).
- **Glass Cards:** For marketplace "Spotlight" items, use a semi-transparent `surface_container_lowest` with a backdrop blur to let the background content softly bleed through.

### Specialized Super-App Components
- **The Module Switcher:** A glassmorphic bottom bar using `secondary_fixed` for active chat states and `tertiary_fixed` for marketplace states.
- **Service Tiles:** Large-format cards (32px radius) using `xl` roundedness, featuring high-fidelity imagery that bleeds to the edges.

---

## 6. Do’s and Don’ts

### Do
- **Do** use white space as a structural element. If a screen feels crowded, increase spacing tokens rather than adding lines.
- **Do** use the `lg` (32px) and `xl` (48px) corner radii for large containers to maintain a soft, modern feel.
- **Do** ensure "Dark Mode" uses `surface_dim` as the base to avoid pure black (#000) "ink smear" on OLED screens.

### Don’t
- **Don’t** use standard 1px grey dividers (`#EEEEEE`). Use a background color change or `spacing-4`.
- **Don’t** place primary buttons too close to each other. Use `spacing-10` (2.5rem) to let them breathe.
- **Don’t** use high-saturation shadows. Shadows must be "ambient"—a soft tint of the background color.
- **Don't** mix the typography scales. If a label is `label-sm`, it must stay `label-sm` across all modules for a unified signature.